import { Component } from '@angular/core';

import {LoginStudent} from './LoginStudent';
import {DatabaseEmailAndPasswordVerification} from './LoginStudent-service';
import {Router} from '@angular/router';


@Component ({
    selector:'login-verification-page',
    templateUrl:'LoginStudent-form.component.html',
    styleUrls: ['LoginStudent.css'],
})
export class LoginFormComponent{

    loginStudent : LoginStudent = new LoginStudent();
    response : string

    constructor(public checkFromDatabase : DatabaseEmailAndPasswordVerification,private router: Router )
    {
      
    }

    verify(mform)
    {
        this.checkFromDatabase.sentToServerForVerification(this.loginStudent)
            .subscribe(data => { 
                console.log("====" + data);
                this.response=data.toString();
                var check=this.response;

                if(check == "true"){
                    console.log("inside if");
                    this.router.navigate(['./register']);
                }
                else{
                    console.log("inside else");
                    this.router.navigate(['./login-verification-page']);
                }
                
            });
            
    }
}