import { Component } from '@angular/core';

import {RegisterStudent} from './RegisterStudent';
import {RegisterServiceAddInDatabaseService} from './RegisterStudent-service'

@Component ({
    selector:'register-data-in-database',
    templateUrl:'RegisterStudent-form.component.html'
})
export class RegisterFormComponent{

    registerStudent : RegisterStudent = new RegisterStudent();
    response : string

    constructor(public registerInDatabase : RegisterServiceAddInDatabaseService )
    {

    }

    add(mform)
    {
        this.registerInDatabase.sentToServer(this.registerStudent)
            .subscribe(data => { 
                console.log("====" + data);
                this.response=data.toString();
            
            })
    }
}