import {Component} from '@angular/core'

export class LoginStudent
{
    constructor(
        public emailAddress?:string,
        public password?:string){

    }
}