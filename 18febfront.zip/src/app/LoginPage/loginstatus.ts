export class LoginStatus {
    status: string;
    name: string;
    customerId: string;
}