import { Component } from '@angular/core';

@Component({
  selector: 'home-click',
  templateUrl: './homeclick.component.html',
  
})
export class HomeClickComponent {
  title = 'SunShine-Bank';
}

