export class Registration {
        constructor(public firstName?: string,
                    public middleName?: string,
                    public lastName?: string,
                    public fatherName?: string,
                    public mobileNo?: number,
                    public email?: string,
                    public aadharno?: string,
                    public address?: string,
                    public accountType?: string,
                    public balance?: string,
                    public password?: string,
                    ) {
    
            }
    }
    