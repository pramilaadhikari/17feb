export class Account{
    accountNumber:number;
    accountType:string;
    balance:number;
    
}