import {Component} from '@angular/core';
export class AccountDetails {

        public firstName:string;
        public lastName:string;
        public email:string;
        public id:number;
        public accnumber:string;
        public name:string;
        public balance:number;
        public account:Account;
       
}
