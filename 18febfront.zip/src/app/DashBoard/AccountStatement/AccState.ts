export class AccountStatememt{

        public transid :number;
        public amount :number;
        public type :string;
        public acc_no:number;
        public account:Account;
        

}