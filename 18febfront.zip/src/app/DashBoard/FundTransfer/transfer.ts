export class Transfer {
    constructor(public fromacc?: number,
                public toacc?: number,
                public amount?: number,
               
                ) {

        }
}
