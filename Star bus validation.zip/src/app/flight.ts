export class Flight {

    constructor(public fno?: number,
        public fname?: string,
        public toCity?: string,
        public fromCity?: string) { }
}
